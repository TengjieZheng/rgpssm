#include <torch/extension.h>
#include <vector>
#include <cmath>

torch::Tensor chol_downdate1(torch::Tensor L, torch::Tensor x) {
    x = x.clone();
    L = L.clone();
    auto n = x.size(0);

    for (int64_t k = 0; k < n; ++k) {
        auto Lkk = L[k][k];
        auto xk = x[k];
        auto r = torch::sqrt(Lkk * Lkk - xk * xk);
        auto c = r / Lkk;
        auto s = xk / Lkk;
        L[k][k] = r;

        if (k + 1 < n) {
            auto L_k1_n_k = L.slice(0, k + 1, n).select(1, k);
            auto x_k1_n = x.slice(0, k + 1, n);
            L_k1_n_k = (L_k1_n_k - s * x_k1_n) / c;
            x_k1_n = c * x_k1_n - s * L_k1_n_k;

            // 更新回原始张量
            L.slice(0, k + 1, n).select(1, k).copy_(L_k1_n_k);
            x.slice(0, k + 1, n).copy_(x_k1_n);
        }
    }

    return L;
}

torch::Tensor chol_downdate(torch::Tensor L, torch::Tensor x) {
    if (x.dim() == 1) {
        x = x.view({-1, 1});
    }
    x = x.clone();
    L = L.clone();
    auto rank = x.size(1);

    for (int64_t ii = 0; ii < rank; ++ii) {
        L = chol_downdate1(L, x.select(1, ii));
    }

    return L;
}

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("chol_downdate1", &chol_downdate1, "Cholesky rank-1 downdate");
    m.def("chol_downdate", &chol_downdate, "Cholesky rank-n downdate");
}
