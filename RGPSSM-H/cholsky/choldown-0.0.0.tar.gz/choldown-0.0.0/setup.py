from setuptools import setup
from torch.utils.cpp_extension import CppExtension, BuildExtension

setup(
    name='choldown',
    ext_modules=[
        CppExtension(
            name='choldown',
            sources=['choldown.cpp'],
        ),
    ],
    cmdclass={
        'build_ext': BuildExtension
    }
)

