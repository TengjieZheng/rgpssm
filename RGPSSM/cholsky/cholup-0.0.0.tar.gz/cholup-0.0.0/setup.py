from setuptools import setup
from torch.utils.cpp_extension import CppExtension, BuildExtension

setup(
    name='cholup',
    ext_modules=[
        CppExtension(
            name='cholup',
            sources=['cholup.cpp'],
        ),
    ],
    cmdclass={
        'build_ext': BuildExtension
    }
)

# setup(
#     name='choldown',
#     ext_modules=[
#         CppExtension(
#             name='choldown',
#             sources=['choldown.cpp'],
#         ),
#     ],
#     cmdclass={
#         'build_ext': BuildExtension
#     }
# )

