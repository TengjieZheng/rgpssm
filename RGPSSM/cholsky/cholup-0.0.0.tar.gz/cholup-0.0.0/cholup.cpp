#include <torch/extension.h>
#include <vector>
#include <cmath>

// Rank-1 update function
torch::Tensor chol_update1(torch::Tensor L, torch::Tensor x) {
    x = x.view(-1).clone();
    L = L.clone();
    auto n = x.size(0);

    for (int64_t k = 0; k < n; ++k) {
        auto Lkk = L[k][k].item<double>();
        auto xk = x[k].item<double>();
        auto r = std::sqrt(Lkk * Lkk + xk * xk);
        auto c = r / Lkk;
        auto s = xk / Lkk;
        L[k][k] = r;

        if (k + 1 < n) {
            for (int64_t i = k + 1; i < n; ++i) {
                L[i][k] = (L[i][k] + s * x[i]) / c;
                x[i] = c * x[i] - s * L[i][k];
            }
        }
    }

    return L;
}

// Rank-n update function
torch::Tensor chol_update(torch::Tensor L, torch::Tensor x) {
    if (x.dim() == 1) {
        x = x.view({-1, 1});
    }
    x = x.clone();
    L = L.clone();
    auto rank = x.size(1);

    for (int64_t ii = 0; ii < rank; ++ii) {
        L = chol_update1(L, x.select(1, ii));
    }

    return L;
}

// Define the functions as PyTorch extensions
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("chol_update1", &chol_update1, "Cholesky rank-1 update");
    m.def("chol_update", &chol_update, "Cholesky rank-n update");
}
